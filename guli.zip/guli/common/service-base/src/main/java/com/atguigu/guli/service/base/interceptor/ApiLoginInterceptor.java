package com.atguigu.guli.service.base.interceptor;

import com.atguigu.guli.common.base.result.R;
import com.atguigu.guli.common.base.result.ResultCodeEnum;
import com.atguigu.guli.common.base.util.JwtUtils;
import com.atguigu.guli.common.base.util.ResponseUtil;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author helen
 * @since 2019/12/10
 */
//@Component
public class ApiLoginInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        System.out.println(request.getRequestURL());
        //判断是否携带token或token是否有效
        if (!JwtUtils.checkToken(request)) {
            //返回封装的http结果
//            throw new GuliException(ResultCodeEnum.LOGIN_AURH);
            ResponseUtil.out(response, R.setResult(ResultCodeEnum.LOGIN_AURH));
        }

        return true;
    }
}
