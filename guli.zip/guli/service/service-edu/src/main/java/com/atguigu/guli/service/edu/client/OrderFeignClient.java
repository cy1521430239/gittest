package com.atguigu.guli.service.edu.client;

import com.atguigu.guli.service.edu.client.exception.OrderFeignClientExceptionHandler;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author helen
 * @since 2019/12/10
 */
@FeignClient(value="guli-order", fallback = OrderFeignClientExceptionHandler.class)
public interface OrderFeignClient {


    @GetMapping("/api/order/inner/is-buy/{memberId}/{courseId}")
    public Boolean isBuyByCourseId(
            @PathVariable(value = "memberId") String memberId,
            @PathVariable(value = "courseId") String courseId);
}


