package com.atguigu.guli.service.edu.client.exception;

import com.atguigu.guli.service.edu.client.OrderFeignClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author helen
 * @since 2019/12/10
 */
@Component
@Slf4j
public class OrderFeignClientExceptionHandler implements OrderFeignClient {
    @Override
    public Boolean isBuyByCourseId(String memberId, String courseId) {
        log.error("熔断器执行");
        return false;
    }
}
