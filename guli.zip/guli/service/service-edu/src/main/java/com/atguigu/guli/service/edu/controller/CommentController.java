package com.atguigu.guli.service.edu.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 评论 前端控制器
 * </p>
 *
 * @author Helen
 * @since 2019-11-20
 */
@RestController
@RequestMapping("/edu/comment")
public class CommentController {

}

