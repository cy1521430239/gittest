package com.atguigu.guli.service.edu.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 课程收藏 前端控制器
 * </p>
 *
 * @author Helen
 * @since 2019-11-20
 */
@RestController
@RequestMapping("/edu/course-collect")
public class CourseCollectController {

}

