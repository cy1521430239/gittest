package com.atguigu.guli.service.edu.service;

import com.atguigu.guli.service.edu.entity.Comment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 评论 服务类
 * </p>
 *
 * @author Helen
 * @since 2019-11-20
 */
public interface CommentService extends IService<Comment> {

}
