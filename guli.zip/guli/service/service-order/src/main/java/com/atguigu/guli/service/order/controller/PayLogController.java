package com.atguigu.guli.service.order.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 支付日志表 前端控制器
 * </p>
 *
 * @author Helen
 * @since 2019-12-10
 */
@RestController
@RequestMapping("/order/pay-log")
public class PayLogController {

}

