package com.atguigu.guli.service.order.service;

import java.util.Map;

/**
 * @author helen
 * @since 2019/12/11
 *
 * 微信支付业务
 */
public interface WeixinPayService {


    /**
     * 根据订单号下单，生成支付链接
     * 订单号不能重复，每次向微信服务器发送生成二维码连接的时候，都要重新生成新的订单号
     * @param orderNo
     * @param remoteAddr
     * @return
     */
    Map<String, Object> createNative(String orderNo, String remoteAddr);


    /**
     * 根据订单号去微信服务器查询当前支付的状态
     * @param orderNo
     * @return
     */
    Map<String, String> queryPayStatus(String orderNo);

    /**
     * 支付成功后更新订单状态
     * @param map
     */
    void updateOrderStatus(Map<String, String> map);
}
