package com.atguigu.guli.service.order.service.impl;

import com.atguigu.guli.common.base.result.ResultCodeEnum;
import com.atguigu.guli.common.base.util.ExceptionUtils;
import com.atguigu.guli.service.base.exception.GuliException;
import com.atguigu.guli.service.order.client.CourseFeignClient;
import com.atguigu.guli.service.order.entity.Order;
import com.atguigu.guli.service.order.entity.PayLog;
import com.atguigu.guli.service.order.mapper.PayLogMapper;
import com.atguigu.guli.service.order.service.OrderService;
import com.atguigu.guli.service.order.service.WeixinPayService;
import com.atguigu.guli.service.order.util.HttpClient;
import com.atguigu.guli.service.order.util.WeixinPayProperties;
import com.github.wxpay.sdk.WXPayUtil;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author helen
 * @since 2019/12/11
 */
@Service
@Slf4j
public class WeixinPayServiceImpl implements WeixinPayService {

    @Autowired
    private OrderService orderService;

    @Autowired
    private WeixinPayProperties weixinPayProperties;

    @Autowired
    private RedisTemplate redisTemplate;

    @Autowired
    private PayLogMapper payLogMapper;

    @Autowired
    private CourseFeignClient courseFeignClient;

    @Override
    public Map<String, Object> createNative(String orderNo, String remoteAddr) {

        try{
            //查询redis中是否有支付对象，如果有则取出
           Map<String, Object> payMap = (Map)redisTemplate.opsForValue().get(orderNo);
           if(payMap != null){
               return payMap;
           }

            //一、根据订单号获取订单信息
            Order order = orderService.getOrderByOrderNo(orderNo);

            //二、调用统一下单接口
            //1、设置参数
            Map<String, String> map = new HashMap<>();
            map.put("appid", weixinPayProperties.getAppid());//appid
            map.put("mch_id", weixinPayProperties.getPartner());//商户号
            map.put("nonce_str", WXPayUtil.generateNonceStr());//随机字符串
            map.put("body", order.getCourseTitle());//课程名称
            map.put("out_trade_no", orderNo);//商户订单号（业务中的订单号）
            map.put("total_fee", order.getTotalFee().multiply(new BigDecimal("100")).intValue() + "");//标价金额
            map.put("spbill_create_ip", remoteAddr);//终端ip
            map.put("notify_url", weixinPayProperties.getNotifyurl());//回调地址
            map.put("trade_type", "NATIVE");//交易类型（微信扫码支付类型）


            //2、使用HttpClient访问微信统一下单接口
            HttpClient httpClient = new HttpClient("https://api.mch.weixin.qq.com/pay/unifiedorder");
            //设置httpClient对象的参数
            httpClient.setXmlParam(WXPayUtil.generateSignedXml(map, weixinPayProperties.getPartnerkey()));
            httpClient.setHttps(true);
            httpClient.post();

            //3、返回响应数据
            String xml = httpClient.getContent();
            Map<String, String> resultMap = WXPayUtil.xmlToMap(xml);

            if("FAIL".equals(resultMap.get("return_code")) || "FAIL".equals(resultMap.get("result_code")) ){
                log.error("统一下单错误 - " +
                        "return_msg: " + resultMap.get("return_msg") + ", " +
                        "err_code: " + resultMap.get("err_code") + ", " +
                        "err_code_des: " + resultMap.get("err_code_des"));
                throw new GuliException(ResultCodeEnum.PAY_UNIFIEDORDER_ERROR);
            }

            //4、封装返回结果集
            HashMap<String, Object> returnMap = new HashMap<>();
            returnMap.put("result_code", resultMap.get("return_code"));
            returnMap.put("code_url", resultMap.get("code_url"));
            returnMap.put("course_id", order.getCourseId());
            returnMap.put("total_fee", order.getTotalFee());
            returnMap.put("out_trade_no", orderNo);

            //将returnMap对象存入redis
            redisTemplate.opsForValue().set(orderNo, returnMap, 120, TimeUnit.MINUTES);

            return returnMap;
        }catch (Exception e){

            log.error(ExceptionUtils.getMessage(e));
            throw  new GuliException(ResultCodeEnum.PAY_UNIFIEDORDER_ERROR);
        }

    }

    @Override
    public Map<String, String> queryPayStatus(String orderNo) {

        try{

            //1、封装参数
            Map<String, String> m = new HashMap<>();
            m.put("appid", weixinPayProperties.getAppid());
            m.put("mch_id", weixinPayProperties.getPartner());
            m.put("out_trade_no", orderNo);
            m.put("nonce_str", WXPayUtil.generateNonceStr());

            //2、使用HttpClient访问订单状态查询接口
            HttpClient httpClient = new HttpClient("https://api.mch.weixin.qq.com/pay/orderquery");
            //设置httpClient对象的参数
            httpClient.setXmlParam(WXPayUtil.generateSignedXml(m, weixinPayProperties.getPartnerkey()));
            httpClient.setHttps(true);
            httpClient.post();


            //3、返回响应数据
            String xml = httpClient.getContent();
            Map<String, String> resultMap = WXPayUtil.xmlToMap(xml);

            if("FAIL".equals(resultMap.get("return_code")) || "FAIL".equals(resultMap.get("result_code")) ){
                log.error("查询支付结果错误 - " +
                        "return_msg: " + resultMap.get("return_msg") + ", " +
                        "err_code: " + resultMap.get("err_code") + ", " +
                        "err_code_des: " + resultMap.get("err_code_des"));
                throw new GuliException(ResultCodeEnum.PAY_ORDERQUERY_ERROR);
            }

            //4、封装响应结果集
            return resultMap;


        }catch (Exception e){

            log.error(ExceptionUtils.getMessage(e));
            throw  new GuliException(ResultCodeEnum.PAY_ORDERQUERY_ERROR);
        }
    }

    /**
     * 支付成功更改订单状态和课程购买数量
     * @param map
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateOrderStatus(Map<String, String> map) {

        //更新订单信息
        String orderNo = map.get("out_trade_no");
        Order order = orderService.getOrderByOrderNo(orderNo);
        order.setStatus(1);
        orderService.updateById(order);

        //记录支付日志
        PayLog payLog=new PayLog();
        payLog.setOrderNo(order.getOrderNo());//支付订单号
        payLog.setPayTime(new Date());
        payLog.setPayType(1);//支付类型
        payLog.setTotalFee(order.getTotalFee().longValue());//总金额(分)
        payLog.setTradeState(map.get("trade_state"));//支付状态
        payLog.setTransactionId(map.get("transaction_id"));
        payLog.setAttr(new Gson().toJson(map));
        payLogMapper.insert(payLog);//插入到支付日志表

        //更新课程购买数量
        courseFeignClient.updateBuyCountById(order.getCourseId());
    }
}
