package com.atguigu.guli.service.sms.controller;

import com.atguigu.guli.common.base.result.R;
import com.atguigu.guli.common.base.util.RandomUtil;
import com.atguigu.guli.service.sms.service.SmsService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

/**
 * @author helen
 * @since 2019/12/7
 */
@CrossOrigin
@Api(description="阿里云短信管理")
@RestController
@RequestMapping("/api/sms")
@Slf4j
public class ApiSmsController {

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Autowired
    private SmsService smsService;

    @GetMapping("send/{phone}")
    public R getCode(@PathVariable String phone){

//        String code = redisTemplate.opsForValue().get(phone);
//        if(!StringUtils.isEmpty(code)){
//            return R.ok();
//        }

        //生成验证码并发送
        String code = RandomUtil.getFourBitRandom();
        HashMap<String, Object> param = new HashMap<>();
        param.put("code", code);
        smsService.send(phone, param);

        redisTemplate.opsForValue().set(phone, code, 5, TimeUnit.MINUTES);
        return R.ok().message("短信发送成功");

//        return R.error().message("短信发送失败");
    }

}
