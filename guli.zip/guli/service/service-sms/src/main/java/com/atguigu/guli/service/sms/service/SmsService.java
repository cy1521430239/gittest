package com.atguigu.guli.service.sms.service;

import java.util.Map;

/**
 * @author helen
 * @since 2019/12/7
 */
public interface SmsService {

    void send(String phoneNumber, Map<String, Object> param);


}
