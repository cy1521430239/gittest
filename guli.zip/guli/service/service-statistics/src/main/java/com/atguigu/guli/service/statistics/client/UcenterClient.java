package com.atguigu.guli.service.statistics.client;

import com.atguigu.guli.common.base.result.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @author helen
 * @since 2019/12/4
 */
@Component
@FeignClient("guli-ucenter")
public interface UcenterClient {

    @GetMapping("/admin/ucenter/member/count-register/{day}")
    public R countRegister(@PathVariable("day") String day);
}
