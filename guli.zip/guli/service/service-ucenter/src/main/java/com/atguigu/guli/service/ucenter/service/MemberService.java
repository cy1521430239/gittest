package com.atguigu.guli.service.ucenter.service;

import com.atguigu.guli.service.base.dto.MemberDto;
import com.atguigu.guli.service.ucenter.entity.Member;
import com.atguigu.guli.service.ucenter.entity.vo.LoginInfoVo;
import com.atguigu.guli.service.ucenter.entity.vo.LoginVo;
import com.atguigu.guli.service.ucenter.entity.vo.RegisterVo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 会员表 服务类
 * </p>
 *
 * @author Helen
 * @since 2019-12-04
 */
public interface MemberService extends IService<Member> {

    Integer countRegisterByDay(String day);

    /**
     * 用户注册
     * @param registerVo
     */
    void register(RegisterVo registerVo);

    /**
     * 用户登录
     * @param loginVo
     * @return token
     */
    String login(LoginVo loginVo);


    /**
     * 获取用户信息
     * @param memberId
     * @return
     */
    LoginInfoVo getLoginInfoVo(String memberId);


    /**
     * 根据openid获取微信用户个人信息
     * @param openid
     * @return
     */
    Member getByOpenid(String openid);


    /**
     * 根据会员id获取会员信息
     * @param memberId
     * @return
     */
    MemberDto getMemberDtoByMemberId(String memberId);
}
