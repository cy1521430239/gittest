package com.atguigu.guli.service.vod.service;

import com.aliyuncs.exceptions.ClientException;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * @author helen
 * @since 2019/11/30
 */
public interface VideoService {

    String uploadVideo(InputStream inputStream, String originalFilename);

    void removeVideo(String videoId) throws ClientException;

    /**
     * 获取视频上传凭证和地址
     * @param title
     * @param fileName
     * @return
     * @throws ClientException
     */
    Map<String, Object> getVideoUploadAuthAndAddress(String title, String fileName) throws ClientException;

    /**
     * 刷新视频上传凭证
     * @param videoId
     * @return
     * @throws ClientException
     */
    Map<String, Object> refreshVideoUploadAuth(String videoId) throws ClientException;

    String getVideoPlayAuth(String videoSourceId) throws ClientException;

    void removeVideoByIdList(List<String> videoSourceIdList) throws ClientException;
}
